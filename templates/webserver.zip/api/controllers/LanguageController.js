/**
 * LanguageController
 *
 * @description :: Server-side logic for managing languages
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */

module.exports = {
	
};

