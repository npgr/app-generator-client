// app-util: version 5.01

// Get URL Params
function url_params()
{  
	var query_string = {};
	var query = window.location.search.substring(1);
	var vars = query.split("&");
	for (var i=0;i<vars.length;i++) {
		var pair = vars[i].split("=");
		// If first entry with this name
		if (typeof query_string[pair[0]] === "undefined") {
			query_string[pair[0]] = decodeURIComponent(pair[1]);
			// If second entry with this name
		} else if (typeof query_string[pair[0]] === "string") {
			var arr = [ query_string[pair[0]],decodeURIComponent(pair[1]) ];
			query_string[pair[0]] = arr;
			// If third or later entry with this name
		} else {
			query_string[pair[0]].push(decodeURIComponent(pair[1]));
		}
	} 
	return query_string;
}

// Return Formated Date
function datex_dma(datex) {
	if (datex) {
		var year = datex.substring( 0, 4)
		var month = datex.substring( 5, 7)
		var day = datex.substring( 8, 10)
		return day+'/'+month+'/'+year
	}
	//else return ''
}

// Call a Page with POST Method
function post(path, params, method) {
    method = method || "post"; // Set method to post by default if not specified.

    // The rest of this code assumes you are not using a library.
    // It can be made less wordy if you use one.
    var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", path);

    for(var key in params) {
        if(params.hasOwnProperty(key)) {
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", key);
            hiddenField.setAttribute("value", params[key]);

            form.appendChild(hiddenField);
         }
    }
    document.body.appendChild(form);
    form.submit();
}

//Drop invalid characters for a file or folder name
// and replace blank space with underscore
function drop_invalid_file_chars(name)
{
	var regex = /[ ]/g
	var output = name.replace(regex, '_')
			
	regex = /[\\/:*?"<>|]/g
	return output.replace(regex, '')
}
