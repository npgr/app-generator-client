<!-- app-config: version 5.00 -->

function config_server() {
	return location.origin + '/'
	//return "http://localhost:3000/"
}

function config_base_url() {
	return "http://localhost:8080/"
}

function config_language() {
	return "Español"
}

function Google_Analytics_id() {
	return 'UA-68195339-1'
	// If this does not exist, Return false
}